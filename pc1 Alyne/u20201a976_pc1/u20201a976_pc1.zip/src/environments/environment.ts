
//a qui se acomodan las APISS
export const environment = {
    development:false,
    baseURL:'https://thecocktaildb.com/api/json/v1/1/search.php?f=a'
};

