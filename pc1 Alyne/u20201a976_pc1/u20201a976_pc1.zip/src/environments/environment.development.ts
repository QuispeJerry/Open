export const environment = {
development:true,
baseURL:'https://thecocktaildb.com/api/json/v1/1/search.php?f=a'
};
