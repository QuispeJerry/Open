import { Injectable } from '@angular/core';

import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CoctelService {

  baseUrl: string=environment.baseURL;
  constructor(private http:HttpClient) { }

  /*getCockteles(index:any){
    console.log(this.baseUrl);
    return this.http.get<any>(`${this.baseUrl}/cocktel/${index}`);
  }*/
}
