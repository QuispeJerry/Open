import { Component } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { CoctelService } from 'src/app/services/coctel-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tabla',
  templateUrl: './tabla.component.html',
  styleUrls: ['./tabla.component.css']
})
export class TablaComponent {

  displayedColumns: string[] = ['Name','Instruction','Date','Glass'];
  data:any[]=[];
  dataSource= new MatTableDataSource<any>(this.data);

  /*constructor(private cocktelService: CoctelService, private router: Router){
  }*/


  /*get_cocktail(){
    let data;
    for(let i=1;i<151;i++){

      this.cocktelService.getCockteles(i).subscribe(

        res=>{
          data={
            Name:res.name,
            Instruction:res.Instruction,
            Date:res.Date,
            Glass:res.Glass, 

          };

          this.data.push(data);
          this.dataSource=new MatTableDataSource<any>(this.data);
    
        },
        err=>{
          console.log(err);
        }
      )
    }


  }*/
  


}
