export interface Menu{
    nombre: string,
    redirect: string
}